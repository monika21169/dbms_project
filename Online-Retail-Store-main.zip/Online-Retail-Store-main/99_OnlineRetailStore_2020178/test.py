def test():
    return "Test is passes"