USE eCartBazzar;

-- 1 Show the average purchased cost of each product:
SELECT T.Product_ID, T.Category_ID, T.Cost, AVG(T.Cost) OVER(PARTITION BY T.Category_ID) AS Avg_Category_Cost
FROM (
    SELECT IP.Product_ID, B.Category_ID, SUM(IP.Cost) AS Cost
    FROM Items_Purchased IP
    JOIN BelongsTo B ON IP.Product_ID = B.Product_ID
    GROUP BY IP.Product_ID
) AS T;

-- 2 Rank items based on their selling quantity: 
SELECT Product_ID, HighestSeller
FROM (
    SELECT Product_ID, SUM(Quantity) AS Quantity, RANK() OVER (ORDER BY Quantity DESC) AS HighestSeller
    FROM Items_Purchased
    GROUP BY Product_ID
) AS H;

-- 3 Rank items based on their selling prices:
SELECT Product_ID, HighestSeller
FROM (
    SELECT Product_ID, SUM(Cost) AS Cost, RANK() OVER (ORDER BY Cost DESC) AS HighestSeller
    FROM Items_Purchased
    GROUP BY Product_ID
) AS H;

-- 4 Calculate total cart cost:
SELECT Temp.Unique_ID, Temp.Username, SUM(Temp.Total) AS "Total cost"
FROM (
    SELECT IC.Unique_ID, IC.Product_ID, U.Name AS Username, SUM(IC.Quantity * P.Product_Cost) AS Total
    FROM Items_Contained IC
    JOIN Product P ON IC.Product_ID = P.Product_ID
    JOIN User U ON IC.Unique_ID = U.User_ID
    WHERE P.Product_ID IN (SELECT Product_ID FROM Inventory WHERE Quantity > 0)
    GROUP BY IC.Unique_ID, IC.Product_ID
) AS Temp
GROUP BY Temp.Unique_ID;

-- 5 Cart total post coupon (assuming coupon_data table):
SELECT *
FROM Coupons
WHERE Coupon_ID = 5; 


-- 6 List orders with products in some category:
SELECT *
FROM Order_Table
WHERE Order_ID IN (
    SELECT DISTINCT IP.Order_ID
    FROM Items_Purchased IP
    WHERE IP.Product_ID IN (
        SELECT Product_ID
        FROM BelongsTo
        WHERE Category_ID = (
            SELECT Category_ID
            FROM Category
            WHERE Category_Name = 'Electronics'
        )
    )
);

-- 7 List out categories and information about them:
SELECT *
FROM Category;

-- 8 Updating the inventory of a product by searching for its name and brand name:
UPDATE Inventory
SET Quantity = 50 -- Replace with the desired quantity
WHERE Product_ID IN (
    SELECT Product_ID
    FROM Product
    WHERE Product_Name = 'Sports Watch'
    AND Brand_ID IN (
        SELECT Brand_ID
        FROM Brand
        WHERE Brand_Name = 'Android Sports Watch'
    )
);

-- 9 List out orders based on whether some product belongs to a particular category:

SELECT *
FROM Order_Table
WHERE Order_ID IN (
    SELECT DISTINCT IP.Order_ID
    FROM Items_Purchased IP
    WHERE IP.Product_ID IN (
        SELECT Product_ID
        FROM BelongsTo
        WHERE Category_ID = (
            SELECT Category_ID
            FROM Category
            WHERE Category_Name = 'Electronics'
        )
    )
);

-- 10 Show orders with product details and user information
SELECT O.Order_id, P.Product_name, U.Name
FROM Order_Table O
JOIN Items_purchased IP ON O.Order_id = IP.Order_id
JOIN Product P ON IP.Product_id = P.Product_id
JOIN User U ON O.Unique_id = U.User_ID;

-- 11 Show unique categories from different tables
SELECT DISTINCT Category_name FROM Category
UNION
SELECT DISTINCT Brand_name FROM Brand;








